package Hotel;

import java.sql.SQLException;

public class test {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		main.reception();
	}
}
