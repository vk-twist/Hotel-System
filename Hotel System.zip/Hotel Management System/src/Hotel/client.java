package Hotel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class client {
	static Scanner sc = new Scanner(System.in);
	public static Connection connect() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/Test";
		String username="root";
		String password="0309";
		Connection con =DriverManager.getConnection(url,username,password);
		
		return con;
	}
	public static void CheckIn () throws SQLException, ClassNotFoundException {
		Scanner sc = new Scanner(System.in);
		Connection con = connect();
		String query="update rooms set customername=? where roomnumber=?";
		System.out.print("Enter Customer Name : ");
		String name=sc.nextLine();
		System.out.print("Enter Room Number : ");
		int roomnumber=sc.nextInt();
		PreparedStatement stm = con.prepareStatement(query);
		System.out.print("Your Room Number  :  "+roomnumber);
		System.out.println();
		stm.setString(1, name);
		stm.setInt(2, roomnumber);
		stm.executeUpdate();
}
	public static void showroomlist() throws ClassNotFoundException, SQLException {
		Connection con = connect();
		String query="Select * from rooms";
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery(query);
		System.out.println("RoomNumber   Price    Non_AC / AC  ");
		System.out.println("---------------------------------------");
		while(res.next()) { 
			System.out.println("     "+res.getInt(1)+"       "+res.getFloat(2)+"      "+res.getString(4));
		}
}
	public static void checkout() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		Connection con = connect();
		String query="update rooms set customername=? where roomnumber=?";
		System.out.print("Enter RoomNumber For Check Out : ");
		int roomnumber=sc.nextInt();
		PreparedStatement stm = con.prepareStatement(query);
		stm.setString(1,"");
		stm.setInt(2, roomnumber);
		stm.executeUpdate();
}
	public static void Available() throws ClassNotFoundException, SQLException {
		Connection con = connect();
		String query="Select * from rooms";
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery(query);
		System.out.println("==========Available Rooms======");
		System.out.println();
		//System.out.println(" RoomNumber    Price    Non_AC / AC  ");
		System.out.println();
		
		while(res.next()) { 
			if(res.getString(3).equals("")) {
				System.out.println("     "+res.getInt(1)+"         "+res.getFloat(2)+"      "+res.getString(4));
			}
		}
}
	public static void BookedRooms() throws SQLException, ClassNotFoundException {
		Connection con = connect();
		String query="Select * from rooms";
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery(query);
		System.out.println("==========Reserved Rooms========");
		System.out.println();
		System.out.println(" RoomNumber    Price    Non_AC / AC  ");
		System.out.println();
		
		while(res.next()) { 
			if(res.getString(3).isEmpty()) {	
			}
			else {
				System.out.println("     "+res.getInt(1)+"         "+res.getFloat(2)+"      "+res.getString(4));	
			}
	}
}
	public static void BookedRoom() throws ClassNotFoundException, SQLException {
		Connection con = connect();
		String query="select * from rooms";
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery(query);
		while(res.next()) {
			if(res.getString(3).isBlank()) {
				System.out.println("     "+res.getInt(1)+"         "+res.getFloat(2)+"      "+res.getString(4));
			}else {
				System.out.println("Try Next Room ");
				break;
			}
		}
	}
	public static void check2() throws ClassNotFoundException, SQLException {
		
		Connection con = connect();
		System.out.print("Enter Room Number : ");
		int num=sc.nextInt();
		String query="Select * from rooms";
		Statement stm = con.createStatement();
		ResultSet res = stm.executeQuery(query);
		while(res.next()) {
			if(res.getString(3).isEmpty()) {
				if(res.getInt(1)==num) {
					CheckIn ();
				}
			}else {
				if(res.getInt(1)==num) {
					System.out.println();
					System.out.println("Try Next Room..");
					break;
				}
			}
		}
		
	}
}

