package Hotel;

import java.sql.SQLException;
import java.util.Scanner;

public class main {

	public static void reception() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("------------Welcome To Kadam Resort----------");
		System.out.println();
		System.out.println("          1 )   Show Room list");
		System.out.println("          2 )   Check In");
		System.out.println("          3 )   Check Out");
		System.out.println("          4 )   Available");
		System.out.println("          5 )   BookedRooms");
		System.out.println("          6 )   Exit");
		System.out.println();
		while (true) {
			System.out.println("=== Enter Your Choice ===");
			System.out.println();
			int ch = sc.nextInt();
			System.out.println();

			if (ch == 1) {
				client.showroomlist();
			} else if (ch == 2) {
				client.check2();
			} else if (ch == 3) {
				client.checkout();
			} else if (ch == 4) {
				client.Available();
			} else if (ch == 5) {
				client.BookedRooms();
			} else if (ch == 6) {
				System.out.println("*************Thanks For Visit************");
				break;
			}
		}
	}
}
